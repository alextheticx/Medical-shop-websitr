// Product Data
const products = {
    featured: [
        {
            id: "featured-1",
            name: "Hayat Herbal Hair Oil",
            image: "../src/assets/hero-hair-oil.jpg",
            price: 1500,
            originalPrice: 2000,
            rating: 5,
            reviews: 156,
            description: "Premium herbal hair oil with 27 natural herbs for hair growth",
            badge: "Best Seller"
        },
        {
            id: "featured-2",
            name: "Men's Vitality Booster",
            image: "../src/assets/products-collection.jpg",
            price: 2500,
            originalPrice: 3000,
            rating: 5,
            reviews: 234,
            description: "Complete herbal solution for men's energy and vitality",
            badge: "Popular"
        }
    ],
    hairCare: [
        {
            id: "hair-1",
            name: "Hayat Herbal Hair Oil",
            image: "../src/assets/products-collection.jpg",
            price: 1500,
            originalPrice: 2000,
            rating: 5,
            reviews: 156,
            description: "Premium herbal hair oil with 27 natural herbs for hair growth and strengthening",
            badge: "Best Seller"
        },
        {
            id: "hair-2",
            name: "Natural Hair Growth Shampoo",
            image: "../src/assets/products-collection.jpg",
            price: 800,
            rating: 4,
            reviews: 89,
            description: "Gentle herbal shampoo for hair growth and hair fall prevention"
        },
        {
            id: "hair-3",
            name: "Anti-Dandruff Herbal Treatment",
            image: "../src/assets/products-collection.jpg",
            price: 1200,
            originalPrice: 1500,
            rating: 5,
            reviews: 134,
            description: "Natural anti-dandruff treatment with neem and tea tree oil",
            badge: "Popular"
        },
        {
            id: "hair-4",
            name: "Hair Strengthening Serum",
            image: "../src/assets/products-collection.jpg",
            price: 2200,
            rating: 4,
            reviews: 78,
            description: "Concentrated serum for weak and damaged hair repair"
        },
        {
            id: "hair-5",
            name: "Herbal Hair Mask",
            image: "../src/assets/products-collection.jpg",
            price: 900,
            rating: 5,
            reviews: 112,
            description: "Deep conditioning hair mask with natural herbs and oils"
        },
        {
            id: "hair-6",
            name: "Scalp Nourishing Oil",
            image: "../src/assets/products-collection.jpg",
            price: 1100,
            rating: 4,
            reviews: 95,
            description: "Specially formulated oil for scalp health and hair growth"
        }
    ],
    mensHealth: [
        {
            id: "mens-1",
            name: "Men's Vitality Booster",
            image: "../src/assets/products-collection.jpg",
            price: 2500,
            originalPrice: 3000,
            rating: 5,
            reviews: 156,
            description: "Complete herbal solution for men's energy and vitality",
            badge: "Best Seller"
        },
        {
            id: "mens-2",
            name: "Strength Enhancement Oil",
            image: "../src/assets/products-collection.jpg",
            price: 1800,
            rating: 4,
            reviews: 89,
            description: "Natural oil for physical strength and endurance"
        },
        {
            id: "mens-3",
            name: "Men's Health Complete Course",
            image: "../src/assets/products-collection.jpg",
            price: 4500,
            originalPrice: 6000,
            rating: 5,
            reviews: 234,
            description: "3-month comprehensive herbal treatment program",
            badge: "Popular"
        },
        {
            id: "mens-4",
            name: "Stamina Booster Capsules",
            image: "../src/assets/products-collection.jpg",
            price: 2200,
            rating: 4,
            reviews: 98,
            description: "Natural capsules for improved stamina and performance"
        },
        {
            id: "mens-5",
            name: "Energy Herbal Mix",
            image: "../src/assets/products-collection.jpg",
            price: 1500,
            rating: 5,
            reviews: 145,
            description: "Traditional herbal blend for natural energy boost"
        },
        {
            id: "mens-6",
            name: "Men's Wellness Tea",
            image: "../src/assets/products-collection.jpg",
            price: 800,
            rating: 4,
            reviews: 67,
            description: "Daily wellness tea for overall men's health"
        }
    ]
};

// Cart Management
class CartManager {
    constructor() {
        this.items = JSON.parse(localStorage.getItem('cart')) || [];
        this.updateCartCount();
    }

    addItem(product) {
        const existingItem = this.items.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.items.push({
                ...product,
                quantity: 1
            });
        }
        
        this.saveCart();
        this.updateCartCount();
        this.showNotification(`${product.name} added to cart!`);
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
    }

    updateQuantity(productId, newQuantity) {
        if (newQuantity <= 0) {
            this.removeItem(productId);
            return;
        }

        const item = this.items.find(item => item.id === productId);
        if (item) {
            item.quantity = newQuantity;
            this.saveCart();
            this.updateCartCount();
            this.renderCart();
        }
    }

    clearCart() {
        this.items = [];
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
    }

    getTotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.items));
    }

    updateCartCount() {
        const count = this.items.reduce((total, item) => total + item.quantity, 0);
        const cartCountElements = document.querySelectorAll('#cart-count');
        cartCountElements.forEach(element => {
            element.textContent = count;
            element.style.display = count > 0 ? 'flex' : 'none';
        });
    }

    showNotification(message) {
        // Simple notification - you can enhance this
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--primary);
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            z-index: 10000;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    renderCart() {
        const cartContent = document.getElementById('cart-content');
        const emptyCart = document.getElementById('empty-cart');
        
        if (!cartContent) return;

        if (this.items.length === 0) {
            cartContent.style.display = 'none';
            if (emptyCart) emptyCart.style.display = 'block';
            return;
        }

        if (emptyCart) emptyCart.style.display = 'none';
        cartContent.style.display = 'block';

        const total = this.getTotal();
        const shipping = total >= 2000 ? 0 : 200;
        const finalTotal = total + shipping;

        cartContent.innerHTML = `
            <div class="cart-grid">
                <div class="cart-items">
                    <div class="cart-header">
                        <h2>Cart Items (${this.items.length})</h2>
                        <button class="btn btn-outline" onclick="cart.clearCart()">
                            <i class="fas fa-trash"></i> Clear Cart
                        </button>
                    </div>
                    ${this.items.map(item => this.renderCartItem(item)).join('')}
                </div>

                <div class="order-summary">
                    <h3>Order Summary</h3>
                    
                    <div class="summary-line">
                        <span>Subtotal:</span>
                        <span>PKR ${total.toLocaleString()}</span>
                    </div>
                    
                    <div class="summary-line">
                        <span>Shipping:</span>
                        <span ${shipping === 0 ? 'style="color: #10b981;"' : ''}>
                            ${shipping === 0 ? 'Free' : 'PKR ' + shipping}
                        </span>
                    </div>
                    
                    ${total < 2000 ? `
                        <div class="free-shipping-notice">
                            Add PKR ${(2000 - total).toLocaleString()} more for free delivery!
                        </div>
                    ` : ''}
                    
                    <div class="summary-line total">
                        <span>Total:</span>
                        <span>PKR ${finalTotal.toLocaleString()}</span>
                    </div>

                    <div class="checkout-actions">
                        <button class="btn btn-primary btn-large">Proceed to Checkout</button>
                        <button class="btn btn-outline btn-large" onclick="window.location.href='index.html'">
                            Continue Shopping
                        </button>
                    </div>

                    <div class="trust-indicators">
                        <div class="trust-item">
                            <span class="checkmark">✓</span>
                            <span>Secure Payment</span>
                        </div>
                        <div class="trust-item">
                            <span class="checkmark">✓</span>
                            <span>Free Returns</span>
                        </div>
                        <div class="trust-item">
                            <span class="checkmark">✓</span>
                            <span>Quality Guaranteed</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderCartItem(item) {
        return `
            <div class="cart-item">
                <div class="cart-item-content">
                    <img src="${item.image}" alt="${item.name}">
                    
                    <div class="cart-item-details">
                        <h3>${item.name}</h3>
                        <p>${item.description}</p>
                        <div class="cart-item-price">PKR ${item.price.toLocaleString()}</div>
                    </div>

                    <div class="cart-item-controls">
                        <div class="quantity-controls">
                            <button class="quantity-btn" onclick="cart.updateQuantity('${item.id}', ${item.quantity - 1})">
                                <i class="fas fa-minus"></i>
                            </button>
                            <span class="quantity-display">${item.quantity}</span>
                            <button class="quantity-btn" onclick="cart.updateQuantity('${item.id}', ${item.quantity + 1})">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>

                        <button class="remove-btn" onclick="cart.removeItem('${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>

                <div class="summary-line" style="margin-top: 1rem; padding-top: 1rem; border-top: 2px solid var(--border);">
                    <span>Item Total:</span>
                    <span style="font-weight: 600;">PKR ${(item.price * item.quantity).toLocaleString()}</span>
                </div>
            </div>
        `;
    }
}

// Initialize cart
const cart = new CartManager();

// Product rendering functions
function renderStars(rating) {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating);
}

function renderProductCard(product) {
    return `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
                ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
            </div>
            
            <div class="product-content">
                <div class="product-rating">
                    <span class="stars">${renderStars(product.rating)}</span>
                    <span class="review-count">(${product.reviews})</span>
                </div>
                
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                
                <div class="product-pricing">
                    <span class="current-price">PKR ${product.price.toLocaleString()}</span>
                    ${product.originalPrice ? `<span class="original-price">PKR ${product.originalPrice.toLocaleString()}</span>` : ''}
                </div>
                
                <button class="btn btn-primary add-to-cart" onclick="cart.addItem(${JSON.stringify(product).replace(/"/g, '&quot;')})">
                    <i class="fas fa-shopping-cart"></i>
                    Add to Cart
                </button>
            </div>
        </div>
    `;
}

function loadProducts() {
    // Load featured products on home page
    const featuredContainer = document.getElementById('featured-products');
    if (featuredContainer) {
        featuredContainer.innerHTML = products.featured.map(renderProductCard).join('');
    }

    // Load hair care products
    const hairContainer = document.getElementById('hair-products');
    if (hairContainer) {
        hairContainer.innerHTML = products.hairCare.map(renderProductCard).join('');
        const countElement = document.getElementById('hair-products-count');
        if (countElement) countElement.textContent = products.hairCare.length;
    }

    // Load men's health products
    const mensContainer = document.getElementById('mens-products');
    if (mensContainer) {
        mensContainer.innerHTML = products.mensHealth.map(renderProductCard).join('');
        const countElement = document.getElementById('mens-products-count');
        if (countElement) countElement.textContent = products.mensHealth.length;
    }
}

// Mobile menu functionality
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const navMenu = document.getElementById('nav-menu');

    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!mobileMenuBtn.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('active');
            }
        });
    }
}

// Contact form functionality
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData);
            
            // Simple validation
            if (!data.firstName || !data.email || !data.message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Simulate form submission
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }
}

// Smooth scrolling for anchor links
function initializeSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    initializeMobileMenu();
    initializeContactForm();
    initializeSmoothScrolling();
    
    // Render cart if on cart page
    if (window.location.pathname.includes('cart.html')) {
        cart.renderCart();
    }
});

// Intersection Observer for animations
function initializeAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.product-card, .collection-card, .value-card, .contact-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Initialize animations after DOM load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeAnimations, 100);
});

// Export for global access
window.cart = cart;
window.products = products;