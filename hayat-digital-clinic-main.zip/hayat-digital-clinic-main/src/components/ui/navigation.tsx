import { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, Search, ShoppingCart, Menu, X } from "lucide-react";
import { Button } from "./button";
import { useCart } from "@/contexts/CartContext";
import logo from "@/assets/logo.png";

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { itemCount } = useCart();

  const menuItems = [
    { label: "Home", href: "/" },
    { 
      label: "Health Categories", 
      href: "/health-categories",
      submenu: [
        { label: "Digestive Health", href: "/digestive-health" },
        { label: "Women's Health", href: "/womens-health" },
        { label: "General Health", href: "/general-health" }
      ]
    },
    { 
      label: "Natural Products", 
      href: "/natural-products",
      submenu: [
        { label: "Hair Care", href: "/hair-care" },
        { label: "Skin Care", href: "/skin-care" },
        { label: "Herbal Oils", href: "/herbal-oils" }
      ]
    },
    { 
      label: "Beauty Products", 
      href: "/beauty-products",
      submenu: [
        { label: "Face Care", href: "/face-care" },
        { label: "Body Care", href: "/body-care" },
        { label: "Natural Cosmetics", href: "/natural-cosmetics" }
      ]
    },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" }
  ];

  return (
    <>
      {/* Promotional Banner */}
      <div className="bg-primary text-primary-foreground text-center py-2 text-sm">
        Enjoy Free Delivery on Orders Above PKR 2000
      </div>

      {/* Main Navigation */}
      <nav className="bg-background border-b border-border sticky top-0 z-50 shadow-soft">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <img src={logo} alt="Faaz Trader" className="h-8 w-auto" />
              <span className="text-xl font-bold text-primary">Faaz Trader</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              {menuItems.map((item) => (
                <div key={item.label} className="relative group">
                  <Link
                    to={item.href}
                    className="flex items-center space-x-1 text-foreground hover:text-primary transition-colors"
                  >
                    <span>{item.label}</span>
                    {item.submenu && <ChevronDown className="w-4 h-4" />}
                  </Link>
                  
                  {/* Dropdown Menu */}
                  {item.submenu && (
                    <div className="absolute top-full left-0 mt-2 w-48 bg-card border border-border rounded-md shadow-medium opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                      <div className="py-2">
                        {item.submenu.map((subitem) => (
                          <Link
                            key={subitem.label}
                            to={subitem.href}
                            className="block px-4 py-2 text-sm text-foreground hover:bg-herb-light hover:text-primary transition-colors"
                          >
                            {subitem.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Right Side Icons */}
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Search className="w-5 h-5" />
              </Button>
              
              <Link to="/cart" className="relative">
                <Button variant="ghost" size="icon">
                  <ShoppingCart className="w-5 h-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Button>
              </Link>

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-card border-t border-border">
            <div className="px-4 py-2 space-y-2">
              {menuItems.map((item) => (
                <div key={item.label}>
                  <Link
                    to={item.href}
                    className="block py-2 text-foreground hover:text-primary transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                  {item.submenu && (
                    <div className="ml-4 space-y-1">
                      {item.submenu.map((subitem) => (
                        <Link
                          key={subitem.label}
                          to={subitem.href}
                          className="block py-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                          onClick={() => setIsMenuOpen(false)}
                        >
                          {subitem.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navigation;