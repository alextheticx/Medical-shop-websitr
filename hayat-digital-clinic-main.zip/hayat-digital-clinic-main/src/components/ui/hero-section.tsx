import { Button } from "./button";
import { Star, Leaf, Heart, Shield } from "lucide-react";
import heroImage from "@/assets/hero-hair-oil.jpg";

const HeroSection = () => {
  const features = [
    { icon: Leaf, text: "27 Natural Herbs" },
    { icon: Star, text: "Premium Quality" },
    { icon: Heart, text: "Hair Growth" },
    { icon: Shield, text: "Dandruff Protection" }
  ];

  return (
    <section className="relative bg-gradient-hero text-white overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-herb-dark/90 to-earth-dark/80" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                FAAZ HERBAL
                <span className="block text-gold">HAIR OIL</span>
              </h1>
              <p className="text-xl text-white/90 max-w-lg">
                Experience the power of 27 natural herbs for silky, smooth, long & strong hair
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-white/10 rounded-lg backdrop-blur-sm">
                  <feature.icon className="w-6 h-6 text-gold" />
                  <span className="text-sm font-medium">{feature.text}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-gold hover:bg-gold-light text-earth-dark font-semibold px-8">
                SHOP NOW!
              </Button>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-earth-dark">
                Learn More
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center space-x-6 pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gold">100%</div>
                <div className="text-sm text-white/80">Natural</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gold">5000+</div>
                <div className="text-sm text-white/80">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gold">★★★★★</div>
                <div className="text-sm text-white/80">Rated</div>
              </div>
            </div>
          </div>

          {/* Right Content - Product Image */}
          <div className="relative animate-float">
            <div className="relative">
              <img 
                src={heroImage} 
                alt="Faaz Herbal Hair Oil"
                className="w-full max-w-lg mx-auto rounded-2xl shadow-strong"
              />
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -left-4 bg-gold text-earth-dark px-4 py-2 rounded-full text-sm font-bold shadow-medium">
                Made with 27 Natural Herbs
              </div>
              
              <div className="absolute -bottom-4 -right-4 bg-white text-earth-dark px-4 py-2 rounded-full text-sm font-bold shadow-medium">
                For Silky, Smooth Hair
              </div>
            </div>

            {/* Background Decorative Elements */}
            <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gold/20 rounded-full blur-3xl" />
          </div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0 overflow-hidden">
        <svg viewBox="0 0 1200 120" className="relative block w-full h-12">
          <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" className="fill-background"></path>
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;