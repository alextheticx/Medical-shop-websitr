import { Link } from "react-router-dom";
import { Button } from "./button";
import { ArrowRight } from "lucide-react";
import ProductCard from "./product-card";
import hairOilBottle from "@/assets/hair-oil-bottle.jpg";
import digestiveCapsules from "@/assets/digestive-capsules.jpg";
import herbalShampoo from "@/assets/herbal-shampoo.jpg";

const CollectionsSection = () => {
  const collections = [
    {
      title: "Digestive Health",
      description: "Discover powerful herbal treatments for digestive wellness",
      image: digestiveCapsules,
      href: "/digestive-health",
      products: 15
    },
    {
      title: "Natural Hair Care",
      description: "Premium herbal oils and shampoos for healthy hair growth",
      image: herbalShampoo,
      href: "/hair-care",
      products: 8
    },
    {
      title: "Beauty Products",
      description: "Natural skincare and beauty products for radiant skin",
      image: hairOilBottle,
      href: "/beauty-products",
      products: 12
    }
  ];

  const featuredProducts = [
    {
      id: "1",
      name: "Faaz Herbal Hair Oil",
      image: hairOilBottle,
      price: 1500,
      originalPrice: 2000,
      rating: 5,
      reviews: 127,
      description: "Natural hair oil with 27 herbs for hair growth and dandruff prevention",
      badge: "Best Seller"
    },
    {
      id: "2", 
      name: "Herbal Shampoo",
      image: herbalShampoo,
      price: 800,
      rating: 4,
      reviews: 89,
      description: "Gentle herbal shampoo for hair growth and hair fall prevention"
    },
    {
      id: "3",
      name: "Digestive Support Capsules",
      image: digestiveCapsules,
      price: 1800,
      originalPrice: 2200,
      rating: 5,
      reviews: 245,
      description: "Complete herbal solution for digestive health and gut wellness",
      badge: "Popular"
    }
  ];

  return (
    <section className="py-20 bg-herb-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Our <span className="text-primary">Collections</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore our range of natural herbal products for complete health and wellness
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {collections.map((collection, index) => (
            <Link key={index} to={collection.href} className="group">
              <div className="relative overflow-hidden rounded-2xl bg-card shadow-soft hover:shadow-medium transition-all duration-300 hover:-translate-y-2">
                <div className="aspect-w-16 aspect-h-10 overflow-hidden">
                  <img 
                    src={collection.image} 
                    alt={collection.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {collection.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {collection.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-primary font-medium">
                      {collection.products} Products
                    </span>
                    <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Featured Products */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-3xl font-bold text-foreground">Featured Products</h3>
            <Button variant="outline" asChild>
              <Link to="/products">
                View All Products
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CollectionsSection;