import Navigation from "@/components/ui/navigation";
import HeroSection from "@/components/ui/hero-section";
import CollectionsSection from "@/components/ui/collections-section";
import Footer from "@/components/ui/footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <CollectionsSection />
      <Footer />
    </div>
  );
};

export default Index;
