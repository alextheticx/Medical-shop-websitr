import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import ProductCard from "@/components/ui/product-card";
import { Button } from "@/components/ui/button";
import { Filter, SortDesc } from "lucide-react";
import hairOilBottle from "@/assets/hair-oil-bottle.jpg";
import herbalShampoo from "@/assets/herbal-shampoo.jpg";
import hairConditioner from "@/assets/hair-conditioner.jpg";

const BeautyProducts = () => {
  const products = [
    {
      id: "1",
      name: "Skin Brightening Face Oil",
      image: hairOilBottle,
      price: 1200,
      originalPrice: 1500,
      rating: 5,
      reviews: 156,
      description: "Natural herbal face oil for glowing and radiant skin",
      badge: "Best Seller"
    },
    {
      id: "2",
      name: "Anti-Aging Face Serum",
      image: herbalShampoo,
      price: 1800,
      rating: 4,
      reviews: 89,
      description: "Herbal serum to reduce fine lines and wrinkles naturally"
    },
    {
      id: "3",
      name: "Acne Treatment Cream",
      image: hairConditioner,
      price: 900,
      originalPrice: 1200,
      rating: 5,
      reviews: 234,
      description: "Natural cream for acne treatment and blemish removal",
      badge: "Popular"
    },
    {
      id: "4",
      name: "Moisturizing Face Mask",
      image: hairOilBottle,
      price: 700,
      rating: 4,
      reviews: 98,
      description: "Hydrating face mask with natural herbs and oils"
    },
    {
      id: "5",
      name: "Dark Circle Remover",
      image: herbalShampoo,
      price: 1100,
      rating: 5,
      reviews: 145,
      description: "Herbal treatment for dark circles and under-eye bags"
    },
    {
      id: "6",
      name: "Fairness Face Pack",
      image: hairConditioner,
      price: 600,
      rating: 4,
      reviews: 67,
      description: "Natural face pack for skin fairness and glow"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Page Header */}
      <section className="bg-gradient-herb text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Beauty & Skincare Products</h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Discover our natural beauty and skincare solutions for radiant and healthy skin
            </p>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12 bg-herb-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm text-muted-foreground">Natural</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">Safe</div>
              <div className="text-sm text-muted-foreground">Chemical Free</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">3000+</div>
              <div className="text-sm text-muted-foreground">Happy Customers</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">★★★★★</div>
              <div className="text-sm text-muted-foreground">Customer Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filters and Sort */}
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline">
                <SortDesc className="w-4 h-4 mr-2" />
                Sort by Price
              </Button>
            </div>
            
            <p className="text-muted-foreground">
              Showing {products.length} products
            </p>
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <Button size="lg" variant="outline">
              Load More Products
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BeautyProducts;