import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Leaf, Heart, Award, Users, Clock, Shield } from "lucide-react";
import collectionsImage from "@/assets/products-collection.jpg";

const About = () => {
  const values = [
    {
      icon: Leaf,
      title: "Natural Ingredients",
      description: "We use only the finest natural herbs and ingredients sourced from trusted suppliers worldwide."
    },
    {
      icon: Heart,
      title: "Health First",
      description: "Your health and wellness are our top priority. Every product is designed with care and expertise."
    },
    {
      icon: Award,
      title: "Quality Assured",
      description: "Rigorous testing and quality control ensure that every product meets our high standards."
    },
    {
      icon: Users,
      title: "Customer Focused",
      description: "We listen to our customers and continuously improve our products based on their feedback."
    }
  ];

  const stats = [
    { number: "15+", label: "Years of Experience" },
    { number: "5000+", label: "Happy Customers" },
    { number: "50+", label: "Natural Products" },
    { number: "27+", label: "Herbal Ingredients" }
  ];

  const timeline = [
    {
      year: "2008",
      title: "Company Founded",
      description: "Started our journey with a vision to provide natural health solutions."
    },
    {
      year: "2012",
      title: "Product Expansion",
      description: "Expanded our product line to include hair care and beauty products."
    },
    {
      year: "2018",
      title: "Online Presence",
      description: "Launched our online store to reach customers nationwide."
    },
    {
      year: "2024",
      title: "Modern Innovation",
      description: "Combining traditional herbal wisdom with modern technology."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-hero text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-5xl font-bold leading-tight">
                About <span className="text-gold">Hayat Dawakhana</span>
              </h1>
              <p className="text-xl text-white/90 leading-relaxed">
                For over 15 years, we have been dedicated to providing premium herbal health products 
                that combine traditional wisdom with modern quality standards. Our mission is to help 
                people achieve optimal health naturally.
              </p>
              <div className="flex items-center space-x-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold">15+</div>
                  <div className="text-sm text-white/80">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold">5000+</div>
                  <div className="text-sm text-white/80">Satisfied Customers</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold">100%</div>
                  <div className="text-sm text-white/80">Natural Products</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={collectionsImage} 
                alt="About Hayat Dawakhana"
                className="w-full rounded-2xl shadow-strong"
              />
              <div className="absolute -bottom-6 -left-6 bg-gold text-earth-dark px-6 py-3 rounded-lg font-bold shadow-medium">
                Trusted Since 2008
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-herb-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="text-center shadow-medium">
              <CardContent className="p-8">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To provide high-quality, natural herbal products that promote health and wellness, 
                  while preserving traditional healing knowledge for future generations. We are committed 
                  to helping people achieve their health goals naturally and safely.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center shadow-medium">
              <CardContent className="p-8">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Leaf className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To become the leading provider of natural health solutions, bridging the gap between 
                  traditional herbal medicine and modern healthcare needs. We envision a world where 
                  natural healing is accessible to everyone.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Our Core Values</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do, from product development to customer service
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-medium transition-shadow">
                <CardContent className="p-6">
                  <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-3">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-20 bg-gradient-herb text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Impact in Numbers</h2>
            <p className="text-xl text-white/90">Building trust through quality and service</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl font-bold text-gold">{stat.number}</div>
                <div className="text-white/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Our Journey</h2>
            <p className="text-xl text-muted-foreground">
              From humble beginnings to becoming a trusted name in herbal health
            </p>
          </div>

          <div className="space-y-8">
            {timeline.map((item, index) => (
              <div key={index} className="flex items-start space-x-6">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                </div>
                <Card className="flex-1">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4 mb-2">
                      <span className="text-2xl font-bold text-primary">{item.year}</span>
                      <h3 className="text-xl font-semibold text-foreground">{item.title}</h3>
                    </div>
                    <p className="text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Assurance */}
      <section className="py-20 bg-herb-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-foreground">
                Quality & <span className="text-primary">Safety</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We maintain the highest standards of quality and safety in all our products. 
                Every batch is tested for purity, potency, and safety before reaching our customers.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Shield className="w-6 h-6 text-primary" />
                  <span className="text-foreground">Rigorous quality testing protocols</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="w-6 h-6 text-primary" />
                  <span className="text-foreground">Traditional preparation methods</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="w-6 h-6 text-primary" />
                  <span className="text-foreground">Certified manufacturing processes</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Leaf className="w-6 h-6 text-primary" />
                  <span className="text-foreground">100% natural ingredients</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={collectionsImage} 
                alt="Quality Assurance"
                className="w-full rounded-2xl shadow-medium"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;