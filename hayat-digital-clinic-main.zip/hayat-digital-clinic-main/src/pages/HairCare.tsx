import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import ProductCard from "@/components/ui/product-card";
import { Button } from "@/components/ui/button";
import { Filter, SortDesc } from "lucide-react";
import hairOilBottle from "@/assets/hair-oil-bottle.jpg";
import herbalShampoo from "@/assets/herbal-shampoo.jpg";
import hairConditioner from "@/assets/hair-conditioner.jpg";

const HairCare = () => {
  const products = [
    {
      id: "hair-1",
      name: "Faaz Herbal Hair Oil",
      image: hairOilBottle,
      price: 1500,
      originalPrice: 2000,
      rating: 5,
      reviews: 156,
      description: "Premium herbal hair oil with 27 natural herbs for hair growth and strengthening",
      badge: "Best Seller"
    },
    {
      id: "hair-2",
      name: "Natural Hair Growth Shampoo",
      image: herbalShampoo,
      price: 800,
      rating: 4,
      reviews: 89,
      description: "Gentle herbal shampoo for hair growth and hair fall prevention"
    },
    {
      id: "hair-3",
      name: "Anti-Dandruff Herbal Treatment",
      image: hairConditioner,
      price: 1200,
      originalPrice: 1500,
      rating: 5,
      reviews: 134,
      description: "Natural anti-dandruff treatment with neem and tea tree oil",
      badge: "Popular"
    },
    {
      id: "hair-4",
      name: "Hair Strengthening Serum",
      image: hairOilBottle,
      price: 2200,
      rating: 4,
      reviews: 78,
      description: "Concentrated serum for weak and damaged hair repair"
    },
    {
      id: "hair-5",
      name: "Herbal Hair Mask",
      image: hairConditioner,
      price: 900,
      rating: 5,
      reviews: 112,
      description: "Deep conditioning hair mask with natural herbs and oils"
    },
    {
      id: "hair-6",
      name: "Scalp Nourishing Oil",
      image: hairOilBottle,
      price: 1100,
      rating: 4,
      reviews: 95,
      description: "Specially formulated oil for scalp health and hair growth"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Page Header */}
      <section className="bg-gradient-herb text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Natural Hair Care Products</h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Transform your hair with our premium collection of herbal hair care products made from natural ingredients
            </p>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12 bg-herb-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">27+</div>
              <div className="text-sm text-muted-foreground">Natural Herbs</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm text-muted-foreground">Chemical Free</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">5000+</div>
              <div className="text-sm text-muted-foreground">Happy Customers</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary">★★★★★</div>
              <div className="text-sm text-muted-foreground">Customer Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filters and Sort */}
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline">
                <SortDesc className="w-4 h-4 mr-2" />
                Sort by Price
              </Button>
            </div>
            
            <p className="text-muted-foreground">
              Showing {products.length} products
            </p>
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <Button size="lg" variant="outline">
              Load More Products
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HairCare;