import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import ProductCard from "@/components/ui/product-card";
import { Button } from "@/components/ui/button";
import { Filter, SortDesc } from "lucide-react";
import digestiveCapsules from "@/assets/digestive-capsules.jpg";
import digestiveTea from "@/assets/digestive-tea.jpg";
import herbalPowder from "@/assets/herbal-powder.jpg";
import digestiveSyrup from "@/assets/digestive-syrup.jpg";
import probioticSupplement from "@/assets/probiotic-supplement.jpg";

const DigestiveHealth = () => {
  const products = [
    {
      id: "1",
      name: "Digestive Support Capsules",
      image: digestiveCapsules,
      price: 1800,
      originalPrice: 2200,
      rating: 5,
      reviews: 156,
      description: "Complete herbal solution for digestive health and gut wellness",
      badge: "Best Seller"
    },
    {
      id: "2",
      name: "Herbal Digestive Tea",
      image: digestiveTea,
      price: 900,
      rating: 4,
      reviews: 89,
      description: "Natural tea blend for improved digestion and stomach comfort"
    },
    {
      id: "3",
      name: "Stomach Relief Powder",
      image: herbalPowder,
      price: 1500,
      originalPrice: 1800,
      rating: 5,
      reviews: 234,
      description: "Herbal powder for immediate stomach relief and digestive support",
      badge: "Popular"
    },
    {
      id: "4",
      name: "Digestive Health Syrup",
      image: digestiveSyrup,
      price: 1200,
      rating: 4,
      reviews: 98,
      description: "Natural syrup for digestive disorders and stomach health"
    },
    {
      id: "5",
      name: "Probiotic Complex",
      image: probioticSupplement,
      price: 2200,
      rating: 5,
      reviews: 145,
      description: "Advanced probiotic supplement for gut health and digestion"
    },
    {
      id: "6",
      name: "Acidity Relief Tablets",
      image: digestiveCapsules,
      price: 600,
      rating: 4,
      reviews: 67,
      description: "Fast-acting tablets for acidity and heartburn relief"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Page Header */}
      <section className="bg-gradient-herb text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Digestive Health Products</h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Discover powerful herbal and traditional treatments for digestive health and stomach wellness
            </p>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filters and Sort */}
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline">
                <SortDesc className="w-4 h-4 mr-2" />
                Sort by Price
              </Button>
            </div>
            
            <p className="text-muted-foreground">
              Showing {products.length} products
            </p>
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <Button size="lg" variant="outline">
              Load More Products
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default DigestiveHealth;